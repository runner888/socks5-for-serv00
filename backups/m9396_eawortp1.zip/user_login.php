<?php
error_reporting(0);
header('Content-Type:text/html;charset=UTF-8');
$username = $_GET['username'];
$password = $_GET['password'];
if(empty($username) || empty($password)) {
	$data = [
            'state' => false,
            'msg' => "账号或密码不能为空！"
        ];
	die(json_encode($data, JSON_UNESCAPED_UNICODE));
}

include 'db_Connect.php';
$sql = "SELECT * FROM users WHERE username='$username' and password='$password'";
$result = $conn->query($sql);

if($result->num_rows === 1){
	$row = $result->fetch_assoc();
	$isblock = $row["isblock"];
	if($isblock == 0){
		$data = [
            'state' => true,
            'vip' => $row["isvip"],
            'viptime' => $row["duedate"]
        ];
	}else{
		$data = [
            'state' => false,
            'errmsg' => "账号限制登录！"
        ];
	}
}else{
	$data = [
            'state' => false,
            'errmsg' => "账号或密码错误！"
        ];
}

include 'db_Close.php';
echo json_encode($data, JSON_UNESCAPED_UNICODE);
?>