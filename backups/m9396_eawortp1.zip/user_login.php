<?php
error_reporting(0);
$username = $_GET['username'] ?? '';
$password = $_GET['password'] ?? '';
if(empty($username) || empty($password)) {
  die(json_encode(['state' => false,'code' => 1001, 'errmsg' => "账号或密码不能为空！"], JSON_UNESCAPED_UNICODE));
}
if (strlen($password) < 32) {
    $password = md5($password . '20220531' . $password);
}
include 'db_Connect.php';
// 使用预处理防止SQL注入
$sql = "SELECT isblock, isvip, duedate, dwCount FROM users WHERE username=? AND password=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();

$data = ['state' => false,'code' => 1002, 'errmsg' => "账号或密码错误！"];

if($result->num_rows === 1){
  $row = $result->fetch_assoc();
  if($row["isblock"] != 0){
    die(json_encode(['state' => false,'code' => 1003, 'errmsg' => "账号限制登录！"], JSON_UNESCAPED_UNICODE));
  }
  // 获取当前日期和时间
  $currentDateTime = new DateTime();
  // 将数据库中的 duedate 转换为 DateTime 对象
  $dueDate = new DateTime($row["duedate"]);

  // 比较当前日期和时间与 duedate
  if ($currentDateTime >= $dueDate) {
    $data = ['state' => false,'code' => 1004, 'errmsg' => "账号已到期！"];
  } else {
    $data = [
      'state' => true,
      'code' => 200,
      'vip' => $row["isvip"],
      'viptime' => $row["duedate"],
      'dwCount' => $row["dwCount"],
    ];
  }
}

include 'db_Close.php';
echo json_encode($data, JSON_UNESCAPED_UNICODE);
?>