<?php
error_reporting(0);
header('Content-Type:application/json;charset=UTF-8');
session_start();  
// 检查用户是否已登录  
if (!isset($_SESSION['user_id'])) {  
    $data = [
            'status' => 'dierror',
            'message' => "失效的缓存需重新登陆"
        ];
	die(json_encode($data, JSON_UNESCAPED_UNICODE));
}  

$referrer = $_POST['referrer'];
if(empty($referrer)) {
	$data = [
            'status' => 'error',
            'message' => "推荐人不能为空"
        ];
	die(json_encode($data, JSON_UNESCAPED_UNICODE));
}

include 'db_Connect.php';
$sql = "SELECT * FROM users_agent WHERE username='$referrer'";
$result = $conn->query($sql);
if($result->num_rows === 1){//推荐人存在
	$row = $result->fetch_assoc();
	$limitnums = $row["limitnums"];
	$usednum = $row["usednum"];
	$data = [
			'status' => 'success',
			'limitnums' => $limitnums,
			'usednum' => $usednum,
			'message' => "查询成功"
		]; 
}else{
	$data = [
			'status' => 'dierror',
			'message' => "用户不存在"
		]; 
}

include 'db_Close.php';
echo json_encode($data, JSON_UNESCAPED_UNICODE);
?>