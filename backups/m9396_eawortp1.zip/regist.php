<?php
error_reporting(0);
header('Content-Type:application/json;charset=UTF-8');
session_start();  
// 检查用户是否已登录  
if (!isset($_SESSION['user_id'])) {  
    $data = [
            'status' => 'dierror',
            'message' => "失效的缓存需重新登陆"
        ];
	die(json_encode($data, JSON_UNESCAPED_UNICODE));
}  

$username = $_POST['username'];
$password = $_POST['password'];
$referrer = $_POST['referrer'];
if(empty($username) || empty($password) || empty($referrer)) {
	$data = [
            'status' => 'error',
            'message' => "账号/密码/推荐人不能为空"
        ];
	die(json_encode($data, JSON_UNESCAPED_UNICODE));
}

$isvip = $_POST['isvip'];
if(empty($isvip)){$isvip = 0;};

$regdate = date("Y-m-d H:i:s");
$duedate = $_POST['duedate'];
if(empty($duedate)){
	$duedate = $regdate;
}

include 'db_Connect.php';
$sql = "SELECT * FROM users_agent WHERE username='$referrer'";
$result = $conn->query($sql);
if($result->num_rows === 1){//推荐人存在
	$row = $result->fetch_assoc();
	$limitnums = $row["limitnums"];
	$usednum = $row["usednum"];
	if($limitnums >0 ){
		$sql = "SELECT * FROM users WHERE username='$username'";
		$result = $conn->query($sql);
		if($result->num_rows > 0){
			$data = [
					'status' => 'error',
					'message' => "用户已存在"
				];
		}else{
			$pw = md5($password.'20220531'.$password);
			$sql = "INSERT INTO users (username, password, isvip, duedate, regdate, referrer) VALUES ('$username', '$pw', $isvip, '$duedate', '$regdate', '$referrer')";  
			
			$result = $conn->query($sql);
			if ($result === TRUE) {
				$sql = "UPDATE users_agent SET limitnums=limitnums-1,usednum=usednum+1 WHERE username = '$referrer'";
				$result = $conn->query($sql);
				$data = [
						'status' => 'success',
						'limitnums' => $limitnums-1,
						'usednum' => $usednum+1,
						'message' => "注册成功"
					];
			} else {  
				$data = [
						'status' => 'error',
						'message' => "注册失败"
					];
			}  
		}
	}else{//注册次数不够
		$data = [
			'status' => 'success',
			'limitnums' => $limitnums,
			'usednum' => $usednum,
			'message' => "注册失败,添加纪录次数不够"
		]; 
	}
}else{
	$data = [
			'status' => 'dierror',
			'message' => "注册失败"
		]; 
}

include 'db_Close.php';
echo json_encode($data, JSON_UNESCAPED_UNICODE);
?>