<?php  
error_reporting(0);
header('Content-Type:application/json;charset=UTF-8');
session_start();  
// 检查用户是否已登录  
if (!isset($_SESSION['user_id'])) {  
    echo json_encode(array('status' => 'dierror'), JSON_UNESCAPED_UNICODE);     // 未登录，重定向到登录页面   
    exit;  
}

$username = $_POST['username'];
if(empty($username)) {
	$data = [
            'status' => 'error',
            'message' => "账号不能为空"
        ];
	die(json_encode($data, JSON_UNESCAPED_UNICODE));
}

$fun = '';
$password = $_POST['password'];
if(!empty($password)) {
	$fun = 'password="'.md5($password.'20220531'.$password).'"';
}
$isvip = $_POST['isvip'];
if(empty($isvip)){$isvip = 0;};
if(empty($fun)) {
	$douhao = '';
}else{
	$douhao = ',';
}	
$fun = $fun.$douhao.'isvip='.$isvip;

$isblock = $_POST['isblock'];
if(empty($isblock)){$isblock = 0;};
if(empty($fun)) {
	$douhao = '';
}else{
	$douhao = ',';
}	
$fun = $fun.$douhao.'isblock='.$isblock;

$duedate = $_POST['duedate'];
if(!empty($duedate)) {
	if(empty($fun)) {
		$douhao = '';
	}else{
		$douhao = ',';
	}
	$fun = $fun.$douhao.'duedate="'.$duedate.'"';
}

if(empty($fun)) {
	$data = [
            'status' => 'success',
            'message' => "修改成功，无变动"
        ];
	die(json_encode($data, JSON_UNESCAPED_UNICODE));
}
include 'db_Connect.php';
// 查询语句  
$sql = "UPDATE users SET ".$fun." WHERE username='$username'";
$result = $conn->query($sql);  

// 检查查询结果  
if($result){  
	$data = [
            'status' => 'success',
            'message' => "修改成功"
        ];
	echo json_encode($data, JSON_UNESCAPED_UNICODE); 
} else {  
    $data = [
            'status' => 'error',
            'message' => "修改失败"
        ];
	echo json_encode($data, JSON_UNESCAPED_UNICODE);
}

// 关闭连接  
include 'db_Close.php';
?>

 