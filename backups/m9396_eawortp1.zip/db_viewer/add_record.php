<?php
// d:\phpstudy_pro\WWW\serv00\db_viewer\add_record.php
require_once 'auth.php';      // 身份验证
require_once 'config.php';    // 配置文件
require_once DB_CONNECT_PATH; // 数据库连接

$selected_table = isset($_GET['table']) ? $_GET['table'] : null;
$table_columns_info = [];
$error_message = '';
$success_message = '';

/**
 * 获取表的列信息，排除自增主键
 *
 * @param mysqli $conn 数据库连接对象
 * @param string $tableName 表名
 * @return array 列信息数组
 */
function getTableColumnsInfo($conn, $tableName) {
    $columns = [];
    $sql = "SHOW COLUMNS FROM `" . $conn->real_escape_string($tableName) . "`";
    $result = $conn->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            // 简单判断是否为自增主键 (更可靠的方法是检查 Key='PRI' AND Extra='auto_increment')
            if (stripos($row['Extra'], 'auto_increment') === false) {
                $columns[] = $row; // 存储完整的列信息，包括类型、是否允许NULL等
            }
        }
        $result->free();
    }
    return $columns;
}

if (!$selected_table) {
    $error_message = "未指定表名。";
} else {
    $table_columns_info = getTableColumnsInfo($conn, $selected_table);
    if (empty($table_columns_info)) {
        $error_message = "无法获取表 '" . htmlspecialchars($selected_table) . "' 的列信息或该表没有可供添加的列 (可能只有自增主键)。";
    }
}

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $selected_table && !empty($table_columns_info)) {
    $values_to_insert = [];
    $placeholders = [];
    $bind_types = '';
    $bind_params_values = [];
    $column_names_for_sql = [];

    foreach ($table_columns_info as $column_info) {
        $column_name = $column_info['Field'];
        if (isset($_POST[$column_name])) {
            $column_names_for_sql[] = "`" . $conn->real_escape_string($column_name) . "`";
            $value = $_POST[$column_name];
            $values_to_insert[] = $value; // 收集原始值用于绑定
            $placeholders[] = '?';
            
            // 根据列类型确定绑定类型 (这是一个简化的示例)
            // 您可能需要更复杂的逻辑来准确判断类型，例如检查 $column_info['Type']
            if (stripos($column_info['Type'], 'int') !== false) {
                $bind_types .= 'i';
            } elseif (stripos($column_info['Type'], 'double') !== false || stripos($column_info['Type'], 'float') !== false || stripos($column_info['Type'], 'decimal') !== false) {
                $bind_types .= 'd';
            } else {
                $bind_types .= 's';
            }
        } else if ($column_info['Null'] === 'NO' && $column_info['Default'] === null) {
            // 如果字段不允许NULL且没有默认值，并且POST中没有提供，则标记错误
            // 对于有默认值的字段，数据库会自动处理
            $error_message = "字段 '" . htmlspecialchars($column_name) . "' 是必需的，但未提供值。";
            break;
        }
    }

    if (empty($error_message)) {
        if (!empty($column_names_for_sql)) {
            $sql = "INSERT INTO `" . $conn->real_escape_string($selected_table) . "` (" . implode(', ', $column_names_for_sql) . ") VALUES (" . implode(', ', $placeholders) . ")";
            $stmt = $conn->prepare($sql);

            if ($stmt) {
                // 动态绑定参数
                $stmt->bind_param($bind_types, ...$values_to_insert);

                if ($stmt->execute()) {
                    $success_message = "新记录已成功添加到表 '" . htmlspecialchars($selected_table) . "'！";
                    // 清空POST数据，防止刷新页面时重复提交 (或者重定向)
                    $_POST = array(); 
                    // header("Location: index.php?table=" . urlencode($selected_table)); // 或者重定向回主页
                    // exit;
                } else {
                    $error_message = "添加记录失败: " . htmlspecialchars($stmt->error);
                }
                $stmt->close();
            } else {
                $error_message = "SQL预处理失败: " . htmlspecialchars($conn->error);
            }
        } else {
            $error_message = "没有要插入的数据。";
        }
    }
}

// 关闭数据库连接 (如果您的 db_Close.php 存在并且需要手动关闭)
// if (file_exists(__DIR__ . '/../db_Close.php')) {
//     require_once __DIR__ . '/../db_Close.php';
// }
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>添加新记录到 <?php echo htmlspecialchars($selected_table); ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav> 
        <span style="font-size: 25px; font-weight: bold;">数据库查看器 - 添加记录</h1></span>
        <a href="index.php?logout=true" style="float: right; margin-right: 20px;">退出</a>
    </nav>
    <div class="container">
        <div class="header-group" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <h3 style="margin: 0;">添加到表: <?php echo htmlspecialchars($selected_table); ?></h3>
    <div class="action-buttons" style="display: flex; gap: 10px;">
        <a href="javascript:history.back()" class="action-button">返回上一页</a>
        <a href="index.php?table=<?php echo urlencode($selected_table); ?>" class="action-button">返回列表</a>
    </div>
</div>

        <?php if ($error_message): ?>
            <p class="error-message"><?php echo $error_message; ?></p>
        <?php endif; ?>
        <?php if ($success_message): ?>
            <p class="success-message"><?php echo $success_message; ?></p>
        <?php endif; ?>

        <?php if ($selected_table && !empty($table_columns_info)): ?>
            <form method="POST" action="add_record.php?table=<?php echo urlencode($selected_table); ?>">
                <?php foreach ($table_columns_info as $column): ?>
                    <div class="form-group">
                        <label for="<?php echo htmlspecialchars($column['Field']); ?>">
                            <?php echo htmlspecialchars($column['Field']); ?> 
                            (<?php echo htmlspecialchars($column['Type']); ?>
                            <?php echo ($column['Null'] === 'NO' && $column['Default'] === null) ? '<span style="color:red;">*</span>' : ''; ?>
                            <?php echo $column['Default'] !== null ? '(默认: ' . htmlspecialchars($column['Default']) . ')' : ''; ?>)
                        </label>
                        <?php 
                        // 根据列类型选择合适的输入框类型 (简化版)
                        $inputType = 'text';
                        if (stripos($column['Type'], 'text') !== false) {
                            $inputType = 'textarea';
                        } elseif (stripos($column['Type'], 'date') !== false) {
                            $inputType = 'date';
                        } elseif (stripos($column['Type'], 'datetime') !== false || stripos($column['Type'], 'timestamp') !== false) {
                            $inputType = 'datetime-local';
                        } elseif (stripos($column['Type'], 'int') !== false || stripos($column['Type'], 'decimal') !== false || stripos($column['Type'], 'float') !== false || stripos($column['Type'], 'double') !== false) {
                            $inputType = 'number';
                            $step = (stripos($column['Type'], 'int') !== false) ? '1' : 'any'; // 整数用step=1，小数用any
                        }
                        ?>
                        <?php if ($inputType === 'textarea'): ?>
                            <textarea name="<?php echo htmlspecialchars($column['Field']); ?>" id="<?php echo htmlspecialchars($column['Field']); ?>"><?php echo isset($_POST[$column['Field']]) ? htmlspecialchars($_POST[$column['Field']]) : ''; ?></textarea>
                        <?php else: ?>
                            <input type="<?php echo $inputType; ?>" 
                                   name="<?php echo htmlspecialchars($column['Field']); ?>" 
                                   id="<?php echo htmlspecialchars($column['Field']); ?>" 
                                   value="<?php echo isset($_POST[$column['Field']]) ? htmlspecialchars($_POST[$column['Field']]) : ''; ?>" 
                                   <?php echo ($inputType === 'number') ? "step='{$step}'" : ''; ?>
                                   <?php echo ($column['Null'] === 'NO' && $column['Default'] === null) ? 'required' : ''; ?>>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
                <button type="submit" class="action-button add-button">添加记录</button>
            </form>
        <?php elseif (!$error_message): ?>
            <p>没有可供添加的列，或者无法加载表信息。</p>
        <?php endif; ?>
    </div>
</body>
</html>