<?php
// d:\phpstudy_pro\WWW\serv00\db_viewer\config.php

/**
 * 配置文件
 * 用于存储应用的基本配置信息
 */

// 固定的访问密钥，请修改为您自己的复杂密钥
define('ACCESS_KEY', 'yushion@chenyu'); // <-- 这是我为您内置的密钥

// 每页显示的记录数
define('RECORDS_PER_PAGE', 20);

// 数据库连接文件路径 (相对于 db_viewer 目录)
define('DB_CONNECT_PATH', __DIR__ . '/../db_Connect.php');

// 启动 session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>