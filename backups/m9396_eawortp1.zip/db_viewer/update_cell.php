<?php
// d:\phpstudy_pro\WWW\serv00\db_viewer\update_cell.php
require_once 'auth.php';      // 身份验证
require_once 'config.php';    // 配置文件
require_once DB_CONNECT_PATH; // 数据库连接

header('Content-Type: application/json'); // 设置响应头为 JSON

$response = ['success' => false, 'message' => '未知错误'];

/**
 * 处理单元格数据更新请求
 *
 * @param mysqli $conn 数据库连接对象
 * @return array 包含操作结果的数组 (success: bool, message: string)
 */
function handleUpdateCell($conn) {
    // 检查请求方法是否为 POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return ['success' => false, 'message' => '无效的请求方法'];
    }

    // 获取并验证必要的参数
    $table = isset($_POST['table']) ? $_POST['table'] : null;
    $column = isset($_POST['column']) ? $_POST['column'] : null;
    $id = isset($_POST['id']) ? $_POST['id'] : null; // 主键值
    $pk_name = isset($_POST['pk_name']) ? $_POST['pk_name'] : null; // 主键列名
    $value = isset($_POST['value']) ? $_POST['value'] : ''; // 新的数据值

    if (empty($table) || empty($column) || empty($id) || empty($pk_name)) {
        return ['success' => false, 'message' => '缺少必要的参数 (表名、列名、主键或值)'];
    }

    // 对输入进行清理，防止 SQL 注入
    $escaped_table = $conn->real_escape_string($table);
    $escaped_column = $conn->real_escape_string($column);
    $escaped_pk_name = $conn->real_escape_string($pk_name);
    $escaped_id = $conn->real_escape_string($id);
    // 对于 $value，我们将在预处理语句中使用，所以这里暂时不转义

    // 构建 SQL 更新语句 (使用预处理语句更安全)
    $sql = "UPDATE `" . $escaped_table . "` SET `" . $escaped_column . "` = ? WHERE `" . $escaped_pk_name . "` = ?";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return ['success' => false, 'message' => 'SQL预处理失败: ' . $conn->error];
    }

    // 绑定参数 (s 代表字符串类型，根据实际数据类型调整)
    // 假设主键和要更新的值都是字符串类型。如果不是，需要根据实际情况调整类型，例如 i (integer), d (double), b (blob)
    $stmt->bind_param('ss', $value, $escaped_id);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            return ['success' => true, 'message' => '数据更新成功！'];
        } else {
            // 没有行受到影响，可能是因为新值与旧值相同，或者记录不存在
            return ['success' => true, 'message' => '数据未发生变化或记录未找到。'];
        }
    } else {
        return ['success' => false, 'message' => '数据更新失败: ' . $stmt->error];
    }

    $stmt->close();
}

// 执行处理函数
$response = handleUpdateCell($conn);

// 关闭数据库连接 (如果您的 db_Close.php 存在并且需要手动关闭)
// if (file_exists(__DIR__ . '/../db_Close.php')) {
//     require_once __DIR__ . '/../db_Close.php';
// }

echo json_encode($response);
?>