<?php
// d:\phpstudy_pro\WWW\serv00\db_viewer\index.php

/**
 * 获取指定表的主键名
 *
 * @param mysqli $conn 数据库连接对象
 * @param string $tableName 表名
 * @return string|null 主键列名，如果不存在则返回 null
 */
function getPrimaryKey($conn, $tableName) {
    $sql = "SHOW KEYS FROM `" . $conn->real_escape_string($tableName) . "` WHERE Key_name = 'PRIMARY'";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $result->free();
        return $row['Column_name'];
    }
    return null;
}

require_once 'auth.php'; // 身份验证
require_once 'config.php'; // 配置文件
require_once DB_CONNECT_PATH; // 数据库连接

/**
 * 主页面
 * 显示数据库表、表数据、提供筛选和分页功能
 */

// 获取所有表名
$tables = [];
$result = $conn->query("SHOW TABLES");
if ($result) {
    while ($row = $result->fetch_array()) {
        $tables[] = $row[0];
    }
    $result->free();
}

// 获取当前选中的表名 (通过 GET 请求)
$selected_table = isset($_GET['table']) ? $_GET['table'] : null;
// 获取当前页码 (通过 GET 请求)
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
// 获取表名筛选条件
$table_filter = isset($_GET['table_filter']) ? $_GET['table_filter'] : '';

$table_data = [];
$table_columns = [];
$total_records = 0;
$total_pages = 1;

$primary_key = null; // 新增：用于存储主键

// 如果有表名筛选，则过滤表列表
if (!empty($table_filter)) {
    $tables = array_filter($tables, function($table_name) use ($table_filter) {
        return stripos($table_name, $table_filter) !== false;
    });
}

// 如果选中了表，则获取表数据
if ($selected_table && in_array($selected_table, $tables)) {
    // 获取主键
    $primary_key = getPrimaryKey($conn, $selected_table);

    // 获取表头 (列名)
    $result = $conn->query("SHOW COLUMNS FROM `" . $conn->real_escape_string($selected_table) . "`");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $table_columns[] = $row['Field'];
        }
        $result->free();
    }

    // 获取总记录数用于分页
    $count_result = $conn->query("SELECT COUNT(*) as total FROM `" . $conn->real_escape_string($selected_table) . "`");
    if ($count_result) {
        $total_records = $count_result->fetch_assoc()['total'];
        $total_pages = ceil($total_records / RECORDS_PER_PAGE);
        $count_result->free();
    }

    // 计算偏移量
    $offset = ($current_page - 1) * RECORDS_PER_PAGE;

    // 获取当前页的数据
    $query = "SELECT * FROM `" . $conn->real_escape_string($selected_table) . "` LIMIT " . RECORDS_PER_PAGE . " OFFSET " . $offset;
    $data_result = $conn->query($query);
    if ($data_result) {
        while ($row = $data_result->fetch_assoc()) {
            $table_data[] = $row;
        }
        $data_result->free();
    }
}

// 处理删除操作
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['table']) && isset($_GET['id']) && $primary_key) {
    $delete_table = $_GET['table'];
    $delete_id = $_GET['id'];

    // 再次确认表名和主键名是合法的，防止意外操作
    if (in_array($delete_table, $tables) && $primary_key) {
        $escaped_delete_table = $conn->real_escape_string($delete_table);
        $escaped_primary_key = $conn->real_escape_string($primary_key);
        // 使用预处理语句进行删除
        $delete_sql = "DELETE FROM `" . $escaped_delete_table . "` WHERE `" . $escaped_primary_key . "` = ? LIMIT 1";
        $stmt = $conn->prepare($delete_sql);
        if ($stmt) {
            $stmt->bind_param('s', $delete_id); // 假设主键是字符串类型，如果是数字，用 'i'
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    // 成功则直接刷新当前页
                    echo "<script>window.location.href='index.php?table=" . urlencode($delete_table) . "&page=" . $current_page . "';</script>";
                } else {
                    // 失败时显示提示
                    echo "<script>alert('删除失败：未找到匹配的记录或记录未被删除。'); window.location.href='index.php?table=" . urlencode($delete_table) . "&page=" . $current_page . "';</script>";
                }
            } else {
                echo "<script>alert('删除操作执行失败: " . htmlspecialchars($stmt->error) . "'); window.location.href='index.php?table=" . urlencode($delete_table) . "&page=" . $current_page . "';</script>";
            }
            $stmt->close();
        } else {
            echo "<script>alert('删除操作SQL预处理失败: " . htmlspecialchars($conn->error) . "'); window.location.href='index.php?table=" . urlencode($delete_table) . "&page=" . $current_page . "';</script>";
        }
    } else {
        echo "<script>alert('无效的表或主键信息，无法删除。'); window.location.href='index.php';</script>";
    }
    exit; // 处理完删除后退出，防止页面继续加载
}

// 关闭数据库连接 (如果您的 db_Close.php 存在并且需要手动关闭)
// if (file_exists(__DIR__ . '/../db_Close.php')) {
//     require_once __DIR__ . '/../db_Close.php';
// }

/**
 * 生成分页链接
 *
 * @param string $selected_table 当前选中的表名
 * @param int $current_page 当前页码
 * @param int $total_pages 总页数
 * @param string $table_filter 当前的表名筛选条件
 * @return string HTML 分页链接
 */
function generatePagination($selected_table, $current_page, $total_pages, $table_filter = '') {
    $pagination_html = '<div class="pagination">';
    $base_url = "index.php?table=" . urlencode($selected_table);
    if (!empty($table_filter)) {
        $base_url .= "&table_filter=" . urlencode($table_filter);
    }

    // 上一页
    if ($current_page > 1) {
        $pagination_html .= '<a href="' . $base_url . '&page=' . ($current_page - 1) . '">&laquo; 上一页</a>';
    }

    // 页码链接 (只显示部分页码)
    $start_page = max(1, $current_page - 2);
    $end_page = min($total_pages, $current_page + 2);

    if ($start_page > 1) {
        $pagination_html .= '<a href="' . $base_url . '&page=1">1</a>';
        if ($start_page > 2) {
            $pagination_html .= '<span>...</span>';
        }
    }

    for ($i = $start_page; $i <= $end_page; $i++) {
        if ($i == $current_page) {
            $pagination_html .= '<a href="#" class="active">' . $i . '</a>';
        } else {
            $pagination_html .= '<a href="' . $base_url . '&page=' . $i . '">' . $i . '</a>';
        }
    }

    if ($end_page < $total_pages) {
        if ($end_page < $total_pages - 1) {
            $pagination_html .= '<span>...</span>';
        }
        $pagination_html .= '<a href="' . $base_url . '&page=' . $total_pages . '">' . $total_pages . '</a>';
    }

    // 下一页
    if ($current_page < $total_pages) {
        $pagination_html .= '<a href="' . $base_url . '&page=' . ($current_page + 1) . '">下一页 &raquo;</a>';
    }

    $pagination_html .= '</div>';
    return $pagination_html;
}

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>数据库查看器</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav>
        <span style="font-size: 25px; font-weight: bold;">数据库查看器 - 添加记录</h1></span>
        <a href="index.php?logout=true" style="float: right; margin-right: 20px;">退出</a>
    </nav>
    <div class="container">
        <h3>数据库表</h3>

        <div class="form-container">
            <form method="GET" action="index.php">
                <input type="text" name="table_filter" placeholder="筛选表名..." value="<?php echo htmlspecialchars($table_filter); ?>">
                <button type="submit">筛选</button>
                <?php if (!empty($table_filter)): ?>
                    <a href="index.php" style="margin-left: 10px;">清除筛选</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="table-list">
            <h3>表列表 (<?php echo count($tables); ?>)</h3>
            <?php if (empty($tables) && !empty($table_filter)): ?>
                <p>没有找到匹配 "<?php echo htmlspecialchars($table_filter); ?>" 的表。</p>
            <?php elseif (empty($tables)): ?>
                <p>数据库中没有表。</p>
            <?php else: ?>
            <ul>
                <?php foreach ($tables as $table): ?>
                    <li><a href="index.php?table=<?php echo urlencode($table) . (!empty($table_filter) ? '&table_filter=' . urlencode($table_filter) : ''); ?>" <?php echo ($selected_table == $table) ? 'style="background-color: #007bff; color: white;"' : ''; ?>><?php echo htmlspecialchars($table); ?></a></li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </div>

        <?php if ($selected_table && in_array($selected_table, $tables)): ?>
            <hr style="margin: 30px 0;">
            <h3>表: <?php echo htmlspecialchars($selected_table); ?> (共 <?php echo $total_records; ?> 条记录)</h3>
            
            <div style="margin-bottom: 15px;">
                <a href="add_record.php?table=<?php echo urlencode($selected_table); ?>" class="action-button add-button">添加新记录</a>
                <a href="export_db.php?table=<?php echo urlencode($selected_table); ?>" class="export-link" style="margin-right:10px; background-color: #ffc107; color: #212529;" title="导出当前表结构和数据">导出此表SQL</a>
                <a href="export_db.php" class="export-link" title="导出整个数据库结构和数据">导出整个库SQL</a>
            </div>

            <?php if (!empty($table_columns) && !empty($table_data)): ?>
                <table>
                    <thead>
                        <tr>
                            <?php foreach ($table_columns as $column): ?>
                                <th><?php echo htmlspecialchars($column); ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($table_data as $row): ?>
                            <tr data-primary-value="<?php echo htmlspecialchars($row[$primary_key]); ?>">
                                <?php foreach ($table_columns as $column): ?>
                                    <td data-column="<?php echo htmlspecialchars($column); ?>" ondblclick="startEdit(this)"><?php echo htmlspecialchars((string)$row[$column]); ?></td>
                                <?php endforeach; ?>
                                <td>
                                    <a href="index.php?action=delete&table=<?php echo urlencode($selected_table); ?>&id=<?php echo urlencode($row[$primary_key]); ?>&page=<?php echo $current_page; ?>" onclick="return confirm('确定要删除这条记录吗？')" class="delete-link">删除</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php echo generatePagination($selected_table, $current_page, $total_pages, $table_filter); ?>
            <?php elseif (!empty($table_columns) && empty($table_data) && $total_records > 0): ?>
                 <p>当前页没有数据。总共有 <?php echo $total_records; ?> 条记录。</p>
                 <?php echo generatePagination($selected_table, $current_page, $total_pages, $table_filter); ?>
            <?php elseif (!empty($table_columns) && empty($table_data)): ?>
                <p>表中没有数据。</p>
            <?php else: ?>
                <p>无法加载表结构或数据。</p>
            <?php endif; ?>
        <?php elseif ($selected_table): ?>
             <hr style="margin: 30px 0;">
            <p style="color: red;">选择的表 '<?php echo htmlspecialchars($selected_table); ?>' 不存在或已被筛选掉。</p>
        <?php endif; ?>

    </div>

    <?php
    // 处理退出逻辑
    if (isset($_GET['logout'])) {
        session_destroy();
        header('Location: login.php');
        exit;
    }
    ?>
<script>
function startEdit(cell) {
    // 保存原始内容并记录到cell的dataset中
    const originalContent = cell.innerHTML;
    cell.dataset.originalContent = originalContent;
    // 替换为输入框并自动聚焦
    cell.innerHTML = `<input type="text" value="${originalContent.replace(/"/g, '\"')}" style="width: 100%; padding: 2px;"
onblur="saveEdit(this, '${cell.dataset.column}')"
onkeypress="if(event.keyCode === 13) saveEdit(this, '${cell.dataset.column}')">`;
    const input = cell.querySelector('input');
    input.focus();
    input.select();
}

function saveEdit(input, column) {
    const cell = input.parentElement;
    const newContent = input.value.trim();
    const originalContent = cell.dataset.originalContent;
    // 取消编辑（内容未修改时）
    if (newContent === originalContent) {
        cell.innerHTML = originalContent;
        return;
    }
    // 显示加载状态
    cell.innerHTML = '<span class="updating">更新中...</span>';
    // 获取行数据
    const row = cell.closest('tr');
    const table = '<?php echo htmlspecialchars($selected_table); ?>';
    const primaryKey = '<?php echo htmlspecialchars($primary_key); ?>';
    const primaryValue = row.dataset.primaryValue;

    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'update_cell.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        cell.innerHTML = newContent;
                    } else {
                        alert(`更新失败：${response.error}`);
                        cell.innerHTML = originalContent;
                    }
                } catch (e) {
                    alert('服务器返回数据格式错误');
                    cell.innerHTML = originalContent;
                }
            } else {
                alert(`请求失败，状态码：${xhr.status}`);
                cell.innerHTML = originalContent;
            }
        }
    };
    xhr.send(`table=${encodeURIComponent(table)}&column=${encodeURIComponent(column)}&id=${encodeURIComponent(primaryValue)}&value=${encodeURIComponent(newContent)}&pk_name=${encodeURIComponent(primaryKey)}`);
}
    </script>
</body>
</html>