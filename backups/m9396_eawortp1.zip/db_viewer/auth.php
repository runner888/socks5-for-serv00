<?php
// d:\phpstudy_pro\WWW\serv00\db_viewer\auth.php
require_once 'config.php';

/**
 * 认证检查
 * 确保用户已通过密钥验证
 */

if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
    // 如果 session 中没有认证标记或标记不为 true，则重定向到登录页面
    header('Location: login.php');
    exit;
}
?>