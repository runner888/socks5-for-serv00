<?php
error_reporting(0);
header('Content-Type: application/json;charset=UTF-8');
$data = $_POST['data'];
$data1 = $_POST['data1'];
$data2 = $_POST['data2'];

echo $data.'|'.$data1.'|'.$data2;
?>