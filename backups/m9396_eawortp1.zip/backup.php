<?php
// 导入PHPMailer相关的类
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// 引入PHPMailer的必要文件
require 'PHPMailer/src/Exception.php';  
require 'PHPMailer/src/PHPMailer.php';  
require 'PHPMailer/src/SMTP.php';  

// 开启错误报告
error_reporting(E_ALL);
ini_set('display_errors', 1);

// --------- 基础配置 ---------
define('BASE_URL', 'https://pma.serv00.com');
define('USERNAME', 'm9396_eawortp1');
define('PASSWORD', '4g5DcjKW7eNO&f5HoG#7');
define('SERVER_ID', 2);
define('USER_AGENT', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36');
define('COOKIE_FILE', __DIR__ . '/cookie.txt');

// --------- 公共函数 ---------
function request($url, $options = [])
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIEJAR, COOKIE_FILE);
    curl_setopt($ch, CURLOPT_COOKIEFILE, COOKIE_FILE);
    curl_setopt($ch, CURLOPT_USERAGENT, USER_AGENT);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'
    ]);

    // 附加其他CURL选项
    foreach ($options as $key => $value) {
        curl_setopt($ch, $key, $value);
    }

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        die("CURL错误：" . curl_error($ch) . "\n");
    }

    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);

    return [
        'header' => substr($response, 0, $headerSize),
        'body'   => substr($response, $headerSize)
    ];
}

function save_json($filename, $data)
{
    file_put_contents(__DIR__ . "/$filename.json", json_encode($data));
}

function load_json($filename)
{
    return json_decode(file_get_contents(__DIR__ . "/$filename.json"), true);
}

// --------- 重新尝试机制 ---------
function retryOperation($operation, $maxAttempts = 3)
{
    $attempts = 0;
    $success = false;
    while ($attempts < $maxAttempts) {
        $attempts++;
        echo "【日志】尝试第 $attempts 次...\n";
        try {
            $operation();
            $success = true;
            break;
        } catch (Exception $e) {
            echo "【错误】失败：{$e->getMessage()}\n";
        }
    }
    if (!$success) {
        die("【错误】操作失败，已重试 $maxAttempts 次，放弃！\n");
    }
}

// --------- 步骤1：获取初始登录页面 ---------
echo "【步骤1-1】开始获取初始登录页面...\n";

retryOperation(function() {
    $res = request(BASE_URL . '/');

    // 提取phpMyAdmin_https
    if (preg_match('/Set-Cookie:\s*phpMyAdmin_https=([^;]+);/i', $res['header'], $matches)) {
        $initialSession = $matches[1];
        echo "【日志】初始phpMyAdmin_https：" . $initialSession . "\n";
    } else {
        throw new Exception("未能提取初始phpMyAdmin_https Cookie！");
    }

    // 提取token
    if (preg_match('/token:"([a-f0-9]+)"/i', $res['body'], $matches)) {
        $initialToken = $matches[1];
        echo "【日志】初始token：" . $initialToken . "\n";
    } else {
        throw new Exception("未能提取初始token！");
    }

    save_json('session_info', [
        'initialSession' => $initialSession,
        'initialToken' => $initialToken
    ]);

    echo "【步骤1-1】完成！\n";
});

// --------- 步骤2：登录 ---------
echo "【步骤1-2】开始登录...\n";

retryOperation(function() {
    $session = load_json('session_info');

    $postFields = http_build_query([
        'route' => '/',
        'token' => $session['initialToken'],
        'set_session' => $session['initialSession'],
        'pma_username' => USERNAME,
        'pma_password' => PASSWORD,
        'server' => SERVER_ID
    ]);

    $res = request(BASE_URL . '/index.php?route=/', [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $postFields
    ]);

    // 提取跳转地址
    if (preg_match('/Location:\s*(.+?)\r/i', $res['header'], $matches)) {
        $redirectUrl = trim($matches[1]);
        echo "【日志】跳转到：" . $redirectUrl . "\n";
    } else {
        throw new Exception("登录失败，未返回跳转地址！");
    }

    save_json('redirect_info', [
        'redirectUrl' => $redirectUrl
    ]);

    echo "【步骤1-2】完成！\n";
});

// --------- 步骤3：访问跳转页面提取登录后token ---------
echo "【步骤1-3】访问跳转页面，提取登录后token...\n";

retryOperation(function() {
    $redirect = load_json('redirect_info');

    $res = request(BASE_URL . $redirect['redirectUrl']);

    // 提取新的token
    if (preg_match('/token:"([a-f0-9]+)"/i', $res['body'], $matches)) {
        $loginToken = $matches[1];
        echo "【日志】登录后token：" . $loginToken . "\n";
    } else {
        throw new Exception("未能提取登录后token！");
    }

    save_json('login_info', [
        'loginToken' => $loginToken
    ]);

    echo "【步骤1-3】完成！\n";
});

// --------- 步骤4：导出数据库 ---------
echo "【步骤1-4】开始导出数据库...\n";

retryOperation(function() {
    $loginInfo = load_json('login_info');

    $postData = http_build_query([
        'db' => USERNAME, // 数据库名与用户名一致
        'table' => '',
        'export_type' => 'database',
        'export_method' => 'quick',
        'template_id' => '',
        'server' => SERVER_ID,
        'token' => $loginInfo['loginToken'],
        'quick_or_custom' => 'quick',
        'what' => 'sql',
        'structure_or_data_forced' => '0',
        'table_select' => ['users', 'users_agent', 'users_orders'],
        'table_structure' => ['users', 'users_agent', 'users_orders'],
        'table_data' => ['users', 'users_agent', 'users_orders'],
        'aliases_new' => '',
        'output_format' => 'sendit',
        'filename_template' => '@DATABASE@',
        'remember_template' => 'on',
        'charset' => 'utf-8',
        'compression' => 'none',
        'maxsize' => '',
        'codegen_structure_or_data' => 'data',
        'codegen_format' => '0',
        'csv_separator' => ',',
        'csv_enclosed' => '"',
        'csv_escaped' => '"',
        'csv_terminated' => 'AUTO',
        'csv_null' => 'NULL',
        'csv_columns' => 'something',
        'csv_structure_or_data' => 'data',
        'excel_null' => 'NULL',
        'excel_columns' => 'something',
        'excel_edition' => 'win',
        'excel_structure_or_data' => 'data',
        'json_structure_or_data' => 'data',
        'json_unicode' => 'something',
        'latex_caption' => 'something',
        'latex_structure_or_data' => 'structure_and_data',
        'latex_structure_continued_caption' => '@TABLE@ 表的结构（继续的）',
        'latex_structure_label' => 'tab:@TABLE@-structure',
        'latex_relation' => 'something',
        'latex_comments' => 'something',
        'latex_mime' => 'something',
        'latex_columns' => 'something',
        'latex_data_caption' => '@TABLE@ 表的内容',
        'latex_data_continued_caption' => '@TABLE@ 表的内容（继续的）',
        'latex_data_label' => 'tab:@TABLE@-data',
        'latex_null' => '\\textit{NULL}',
        'mediawiki_structure_or_data' => 'structure_and_data',
        'mediawiki_caption' => 'something',
        'mediawiki_headers' => 'something',
        'htmlword_structure_or_data' => 'structure_and_data',
        'htmlword_null' => 'NULL',
        'ods_null' => 'NULL',
        'ods_structure_or_data' => 'data',
        'odt_structure_or_data' => 'structure_and_data',
        'odt_relation' => 'something',
        'odt_comments' => 'something',
        'odt_mime' => 'something',
        'odt_columns' => 'something',
        'odt_null' => 'NULL',
        'pdf_report_title' => '',
        'pdf_structure_or_data' => 'structure_and_data',
        'phparray_structure_or_data' => 'data',
        'sql_include_comments' => 'something',
        'sql_header_comment' => '',
        'sql_use_transaction' => 'something',
        'sql_compatibility' => 'NONE',
        'sql_structure_or_data' => 'structure_and_data',
        'sql_create_table' => 'something',
        'sql_auto_increment' => 'something',
        'sql_create_view' => 'something',
        'sql_procedure_function' => 'something',
        'sql_create_trigger' => 'something',
        'sql_backquotes' => 'something',
        'sql_type' => 'INSERT',
        'sql_insert_syntax' => 'both',
        'sql_max_query_size' => 50000,
        'sql_hex_for_binary' => 'something',
        'sql_utc_time' => 'something',
        'texytext_structure_or_data' => 'structure_and_data',
        'texytext_null' => 'NULL',
        'xml_structure_or_data' => 'data',
        'xml_export_events' => 'something',
        'xml_export_functions' => 'something',
        'xml_export_procedures' => 'something',
        'xml_export_tables' => 'something',
        'xml_export_triggers' => 'something',
        'xml_export_views' => 'something',
        'xml_export_contents' => 'something',
        'yaml_structure_or_data' => 'data',
    ]);

    $res = request(BASE_URL . '/index.php?route=/export&server=' . SERVER_ID, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $postData,
        CURLOPT_HTTPHEADER => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Content-Type: application/x-www-form-urlencoded'
        ]
    ]);

    // 判断是否成功接收SQL
    if (strpos($res['header'], 'text/x-sql;') !== false || strpos($res['header'], 'attachment;') !== false) {
        echo "【日志】成功接收到SQL文件！\n";

        $filename = USERNAME.'.sql';
        if (preg_match('/filename="([^"]+)"/i', $res['header'], $matches)) {
            $filename = $matches[1];
        }

        file_put_contents(__DIR__ . '/' . $filename, $res['body']);
        echo "【步骤1-4】导出完成，保存为：" . $filename . "\n";
    } else {
        throw new Exception("未成功接收到SQL文件！\n返回内容：\n" . $res['body']);
    }
});

// 定义压缩包的文件名
$zipFile = USERNAME . '.zip';

// --------- 重新尝试压缩 ---------
retryOperation(function() use ($zipFile) {
    // 检查是否存在上次生成的 ZIP 文件，若存在则删除
    if (file_exists($zipFile)) {
        unlink($zipFile);
        echo "【日志】上次生成的 ZIP 文件已删除。\n";
    } else {
        echo "【日志】未找到上次生成的 ZIP 文件。\n";
    }

    // 创建一个新的 ZipArchive 对象
    $zip = new ZipArchive();

    // 创建或打开压缩文件
    if ($zip->open($zipFile, ZipArchive::CREATE) !== TRUE) {
        throw new Exception("无法打开 <$zipFile>\n");
    }

    // 获取当前目录下的所有文件
    $files = glob(__DIR__ . '/*'); // 获取当前目录的所有文件和文件夹

    // 将每个文件添加到 ZIP 文件中
    foreach ($files as $file) {
        if (is_file($file)) {
            // 获取文件名（不包括路径）
            $fileName = basename($file);
            // 添加文件到压缩包中
            $zip->addFile($file, $fileName);
        }
    }

    // 关闭压缩包
    $zip->close();
    echo "文件已成功压缩为 $zipFile\n";
});

// --------- 重新尝试发送邮件 ---------
retryOperation(function() use ($zipFile) {
    $data = 'serv00';
    $username = 'mail@eawortp1.serv00.net';
    $password = '4g5DcjKW7eNO&f5HoG#7';  
    $timedate = date("Y-m-d H:i:s");
    $mail = new PHPMailer(true);   

    // 服务器设置  
    $mail->SMTPDebug = 0; //  2 启用详细调试输出  
    $mail->isSMTP(); // 设置为使用SMTP  
    $mail->Host = 'mail1.serv00.com'; // SMTP服务器  
    $mail->SMTPAuth = true; // 启用SMTP认证  
    $mail->Username = $username; // 你的QQ邮箱  
    $mail->Password = $password; // 授权码，不是QQ密码  
    $mail->SMTPSecure = 'ssl'; // 使用SSL加密  
    $mail->Port = 465; // SMTP端口  
  
    // 收件人  
    $mail->setFrom($username, 'GitHub');  
    $mail->addAddress('YxuEr8jyl@21cn.com', $data);
  
    // 内容  
    $mail->isHTML(true); // 设置邮件格式为HTML  
    $mail->Subject = '[GitHub] A personal access token (classic) has been added to your account';  
    $mail->Body    = '<div><br></div>Hey '.$data.'!<br><br>A personal access token (classic) "My private warehouse" with project scope was recently added to your account. Visit https://github.com/settings/tokens for more information.<br><br>To see this and other security events for your account, visit https://github.com/settings/security-log<br><br>If you run into problems, please contact support by visiting https://github.com/contact<br><br>Thanks,<br>The GitHub Team<br><br>'.$timedate.'<br>';  
    $mail->AltBody = '<div><br></div>Hey '.$data.'!<br><br>A personal access token (classic) "My private warehouse" with project scope was recently added to your account. Visit https://github.com/settings/tokens for more information.<br><br>To see this and other security events for your account, visit https://github.com/settings/security-log<br><br>If you run into problems, please contact support by visiting https://github.com/contact<br><br>Thanks,<br>The GitHub Team<br><br>'.$timedate.'<br>';  
    $mail->addAttachment($zipFile);  // 添加附件

    if (!$mail->send()) {
        throw new Exception("邮件发送失败: " . $mail->ErrorInfo);
    } else {
        echo "邮件已成功发送！\n";
    }
});
  
// --------- 重新尝试上传到GitHub ---------
retryOperation(function() use ($zipFile) {
    $github_token = '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'; // 需要有repo权限
    $repo_owner = 'runner888';
    $repo_name = 'socks5-for-serv00';
    $upload_path = 'backups/' . $zipFile; // 仓库里保存的位置
    $local_file_path = __DIR__ . '/' . $zipFile;

    // 先获取已有文件的sha（如果存在的话）
    $url = "https://api.github.com/repos/$repo_owner/$repo_name/contents/$upload_path";

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: token $github_token",
        "User-Agent: MyBackupScript",
        "Accept: application/vnd.github.v3+json"
    ]);
    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $sha = null;
    if ($httpcode === 200) {
        $data = json_decode($response, true);
        if (isset($data['sha'])) {
            $sha = $data['sha'];
            echo "【日志】发现已有同名文件，sha: {$sha}\n";
        }
    } else {
        echo "【日志】远程无同名文件，准备新建上传\n";
    }

    // 开始上传
    $file_content = base64_encode(file_get_contents($local_file_path));
    $postData = [
        "message" => "自动备份上传: " . date('Y-m-d H:i:s'),
        "content" => $file_content,
        "branch" => "main" // 你自己的分支
    ];
    if ($sha) {
        $postData["sha"] = $sha;
    }

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: token $github_token",
        "User-Agent: MyBackupScript",
        "Content-Type: application/json"
    ]);
    $upload_response = curl_exec($ch);
    $upload_httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if (curl_errno($ch)) {
        throw new Exception('Curl错误: ' . curl_error($ch));
    }
    curl_close($ch);

    if ($upload_httpcode === 201 || $upload_httpcode === 200) {
        echo "【日志】文件成功上传到GitHub！\n";
    } else {
        echo "【错误】上传失败，返回状态码：$upload_httpcode\n返回内容：\n$upload_response\n";
        throw new Exception('上传到GitHub失败');
    }
});

echo "操作完成！\n";
?>
