<?php  
error_reporting(0);
header('Content-Type:application/json;charset=UTF-8');
session_start();  
// 检查用户是否已登录  
if (!isset($_SESSION['user_id'])) {  
    echo json_encode(array('status' => 'dierror','message' => "失效的缓存需重新登陆"), JSON_UNESCAPED_UNICODE);     // 未登录，重定向到登录页面   
    exit;  
}

$username = $_GET['username'];
if(empty($username)) {
	$data = [
            'status' => 'error',
            'message' => "账号不能为空"
        ];
	die(json_encode($data, JSON_UNESCAPED_UNICODE));
}

include 'db_Connect.php';
  
// 查询语句  
$sql = "SELECT * FROM users WHERE username='$username'";
$result = $conn->query($sql);  

// 检查查询结果  
if($result->num_rows === 1){  
	$row = $result->fetch_assoc();
	unset($row['id']);
	unset($row['password']);
	//unset($row['duedate']);  
	unset($row['regdate']);  
	unset($row['referrer']);  

    echo json_encode(array('status' => 'success','data' => $row), JSON_UNESCAPED_UNICODE);  
} else {  
    echo json_encode(array('status' => 'error','message' => '用户不存在'), JSON_UNESCAPED_UNICODE);  
}

// 关闭连接  
include 'db_Close.php';
?>

 