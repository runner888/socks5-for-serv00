<?php  
error_reporting(0);
header('Content-Type:application/json;charset=UTF-8');
session_start();  
// 检查用户是否已登录  
if (!isset($_SESSION['user_id'])) {  
    echo json_encode(array('status' => 'dierror'));     // 未登录，重定向到登录页面  
    exit;  
}  
$referrer = $_SESSION['user_id'];
include 'db_Connect.php';

// 查询语句  
$sql = "SELECT * FROM users WHERE referrer='$referrer'"; // 将 your_table 替换为你的表名  
$result = $conn->query($sql);  

// 检查查询结果  
if ($result->num_rows > 0) {  
    $data = array();  
    while($row = $result->fetch_assoc()) {  
        $data[] = $row; 
    }
	foreach ($data as &$item) {  
		unset($item['password']);  
		unset($item['isblock']);  
		unset($item['regdate']);  
		unset($item['referrer']);  
	} 
    echo json_encode(array('status' => 'success','data' => $data));  
} else {  
    echo json_encode(array('status' => 'success','data' => []));  
}

// 关闭连接  
include 'db_Close.php';
?>

 