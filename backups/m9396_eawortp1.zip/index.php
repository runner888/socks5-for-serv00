<?php
error_reporting(0);
header('Content-Type:text/html;charset=UTF-8');
session_start();  
// 检查用户是否已登录  
if (!isset($_SESSION['user_id'])) {  
    header('Location: login.html'); // 未登录，重定向到登录页面  
    exit;  
}  
$username = $_SESSION['user_id'];
?>

<!DOCTYPE html>  
<html lang="en">
<head>  
    <meta charset="UTF-8">  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <title></title>  
    
    <link rel="stylesheet" href="js/styles.css">  
</head>  
<body>  
    <div id="container" class="container" data-spm="<?php echo $username ?>">
	
    </div>
	<div id="pageination" class="pagination"><span id="firstPage">首页</span><span id="prevPage">上一页</span><span id="currentPage">1</span><span id="nextPage" href="#">下一页</span><span id="lastPage">尾页</span></div></br>
	<div style="padding:30px;"></div>
	
	<!-- 底部导航 -->  
	<div id="myPopup" class="popup">  
		<div class="content">  
		<span id="closePopup" class="closePopup"></span>
			<form id="popupForm">
				<h2>修改记录</h2>
				<div class="form-group">  
					<label for="username">用户名:</label>
					<input type="text" id="pusername" style="color: #888;background-color: #f5f5f5; cursor: not-allowed;" name="username" readonly>
				</div>  
				<div class="form-group">  
					<label for="password">密码:</label>  
					<input type="text" id="ppassword" name="password">  
				</div>
				<!--<div class="form-group">  
					<label for="duedate">到期时间:</label>  
					<input type="datetime-local" id="pduedate" name="duedate">  
				</div>-->
				<div class="form-group">  
					<label for="isblock">黑名单:</label>  
					<select id="pisblock" name="isblock">  
						<option value="0"> 0 -- 正常</option>  
						<option value="1"> 1 -- 拉黑</option>  
					</select>  
				</div>
				<div class="form-group">  
					<label for="isvip">用户等级:</label>  
					<select id="pisvip" name="isvip" required>  
					<option value="0"> 0 -- 普通</option>  
					<option value="1"> 1 -- Vip</option>  
					<option value="2"> 2 -- SVip</option>  
					</select>  
				</div>
				<button type="submit"  class="addbutton">修改</button>  
			</form> 
			  
		</div>  
	</div>  
    <nav class="bottom-nav">  
        <a href="javascript:void(0)" id="addfun" class="nav-item">增加(<?php echo $limitnums ?>)</a>  
        <a href="javascript:void(0)" id="findfun"  class="nav-item">查询</a>  
        <a href="loginout.php" id="exitfun"  class="nav-item">退出</a>   
    </nav> 
    <script src="js/script.js"></script> 
</body>  
</html>