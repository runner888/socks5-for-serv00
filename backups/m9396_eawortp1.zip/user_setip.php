<?php
error_reporting(0);
$username = $_GET['username'] ?? '';
if(empty($username)) {
  die(json_encode(['state' => false, 'errmsg' => "账号不能为空！"], JSON_UNESCAPED_UNICODE));
}
include 'db_Connect.php';

$ip = $_GET['ip'] ?? '';       
$frpip = $_GET['frpip'] ?? '';  
$frpconfig = $_GET['frpconfig'] ?? '';
$hapip = $_GET['hapip'] ?? '';

// 修复3: UPDATE使用预处理
$update_sql = "UPDATE users SET ip=?, frpip=?, frpconfig=?, hapip=? WHERE username=?";
$stmt = $conn->prepare($update_sql);
$stmt->bind_param("sssss", $ip, $frpip, $frpconfig, $hapip, $username);
$state = $stmt->execute();

include 'db_Close.php';
echo json_encode(['state' => $state], JSON_UNESCAPED_UNICODE);
?>