<?php  
error_reporting(0);
header('Content-Type:text/html;charset=UTF-8');
session_start();  
  
// 销毁会话并清除会话cookie  
session_destroy();  
// 清除会话cookie（可选，但推荐）  
setcookie(session_name(), '', time() - 3600, '/');  
setcookie('user_id', '', time() - 3600, '/');  
//setcookie(session_id(), '', time() - 3600, '/'); 
$_SESSION = array(); 
  
// 重定向到登录页面或首页  
header('Location: login.html');
exit;
?>