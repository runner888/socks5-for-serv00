function addFunction() {
	document.getElementById('pageination').style.display = 'none';
	getlimit();
    // 获取 div 元素
	var divElement = document.getElementById('container');
	// 修改 div 的内容
	divElement.innerHTML = '<div class="content"><form id="userForm"><h2>增加记录</h2><div class="form-group">  <label for="username">用户名:</label><input type="text" id="username" name="username" required></div>  <div class="form-group">  <label for="password">密码:</label>  <input type="text" id="password" name="password" required>  </div>  <div class="form-group">  <label for="duedate">到期时间:</label>  <input type="datetime-local" id="duedate" name="duedate" required>  </div>  <div class="form-group">  <label for="referrer">推荐:</label>  <input type="text" id="referrer" name="referrer" value="" readonly>  </div>  <div class="form-group">  <label for="isvip">用户等级:</label>  <select id="isvip" name="isvip">  <option value="0"> 0 -- 普通</option>  <option value="1"> 1 -- Vip</option>  <option value="2"> 2 -- SVip</option>  </select>  </div>  <button type="submit"  class="addbutton">添加</button>  </form></div>';

  
	// 创建一个新的<script>元素  
	var script = document.createElement('script');  
	script.type = 'text/javascript';  
	  
	// 设置脚本内容（对于内联脚本）  
	script.async = true; // 可选，表示异步加载和执行  
	script.textContent = "var idReferrer = document.getElementById('referrer');idReferrer.value = document.getElementById('container').getAttribute('data-spm');var idExpiry_date = document.getElementById('duedate');var now = new Date();var year = now.getFullYear()+1;var month = String(now.getMonth() + 1).padStart(2, '0');var day = String(now.getDate()).padStart(2, '0');var hours = String(now.getHours()).padStart(2, '0');var minutes = String(now.getMinutes()).padStart(2, '0');var seconds = String(now.getSeconds()).padStart(2, '0');var formattedDateTime = year + '-' + month + '-' + day + 'T' + hours + ':' + minutes;idExpiry_date.value = formattedDateTime;document.getElementById('userForm').addEventListener('submit', function(e) {  e.preventDefault();var formData = new FormData(this);var xhr = new XMLHttpRequest();xhr.open('POST', 'regist.php', true);xhr.responseType = 'json';xhr.onload = function() {if(xhr.response.status === 'dierror'){window.location.href = 'loginout.php';}else if(xhr.response.status === 'success'){alert(xhr.response.message);addFunction();}else{alert(xhr.response.message);}}; xhr.send(formData); });";  
	
	// 将<script>元素添加到DOM中  
	divElement.appendChild(script);
}
document.getElementById('addfun').addEventListener('click', function(event) {
    addFunction();
});
document.addEventListener('DOMContentLoaded', function() {
	addFunction();
});

function findFunction(param) {
	document.getElementById('pageination').style.display = 'block';
    // 获取 div 元素
	var divElement = document.getElementById('container');
	// 修改 div 的内容
	divElement.innerHTML = '<div class="content"><div class="tagname"><h2>查询记录</h2></div><div class="search"><input type="text" id="searchInput" placeholder="搜索..."><button id="searchButton" onclick="jumpToAnchor()">搜索</button> </div><div id="responid" class="respon"></div><button id="backToTopBtn" onclick="topFunction()"></button></div>';

  
	// 创建一个新的<script>元素  
	var script = document.createElement('script');  
	script.type = 'text/javascript';  
	  
	// 设置脚本内容（对于内联脚本）  
	script.async = true; // 可选，表示异步加载和执行  
	script.textContent = "function jumpToAnchor() {var searchValue = document.getElementById('searchInput').value;var anchorElement = findvalue(searchValue);  if (!anchorElement) {alert('未找到！');}}window.onscroll = function() {scrollFunction()};function scrollFunction() {if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {document.getElementById('backToTopBtn').style.display = 'block';} else {document.getElementById('backToTopBtn').style.display = 'none';}}function topFunction() {document.body.scrollTop = 0;document.documentElement.scrollTop = 0;};getquery("+param+");";  
	
	// 将<script>元素添加到DOM中  
	divElement.appendChild(script);
}
document.getElementById('findfun').addEventListener('click', function(event) {
    findFunction();
});
var searchFind = false;
var searchFindValue = '';
function findvalue(searchValue){
	searchFind = true;
	searchFindValue = searchValue;
	for (let key in groupedinnerHTMLsigner) {  
	  if (groupedinnerHTMLsigner.hasOwnProperty(key)) { // 确保键是对象自身的属性，而不是继承的
		if(searchValue === key){	
			var element = document.getElementById('responid');
			element.innerHTML  = groupedinnerHTMLsigner[key];
			return true;
		}
	  }  
	} 
	return false;
}
function getlimit(){
	var xhr = new XMLHttpRequest();
	xhr.open('GET', 'getlimit.php', true);
	xhr.responseType = 'json';
	xhr.onload = function() {
		if(xhr.response.status === 'success'){
			document.getElementById('addfun').innerText = "增加(" + xhr.response.limitnums+")";
		}else if(xhr.response.status === 'dierror'){
			window.location.href = 'loginout.php';
		}else{
			alert(xhr.response.message);
		}
	}; 
	xhr.send(); 
}
var groupedinnerHTMLsigner = {};
var groupedinnerHTML = [];

var totalPages = 0;  
var currentPage = 1; 
function setPages(param){
	totalPages = groupedinnerHTML.length;  
	currentPage = param; 
	updateCurrentPageDisplay(param);
}
function getquery(param){
	groupedinnerHTMLsigner = {};
	groupedinnerHTML = [];
	var formData = new FormData();
	var xhr = new XMLHttpRequest();
	xhr.open('GET', 'query.php', true);
	xhr.responseType = 'json';
	xhr.onload = function() {
		if(xhr.response.status === 'success'){
			var innerHTMLsigner = '';
			var newinnerHTML = '';
			for (let i = 0; i < xhr.response.data.length; i++) {
				innerHTMLsigner = '<div class=\"parent-div\"><div class=\"child-div-0\">'+(i+1)+'</div><div class=\"child-div-container\"><div class=\"child-div-1\">  <div class=\"divname\">&nbsp;用&nbsp;&nbsp;户&nbsp;&nbsp;名&nbsp;</div><span>&nbsp;&nbsp;&nbsp;'+xhr.response.data[i].username+'</span></div><div class=\"child-div-2\"><div class=\"divname\">&nbsp;等&nbsp;级&nbsp;</div><span>&nbsp;&nbsp;&nbsp;'+xhr.response.data[i].isvip+'</span></div></div> <div id=\"'+xhr.response.data[i].username+'\" class=\"child-div-3\"><div class=\"divname\">&nbsp;到期时间&nbsp;</div><span>&nbsp;&nbsp;&nbsp;'+xhr.response.data[i].duedate+'</span><span class=\"spanimage\" onclick=\"tanchuang(event)\"></span></div></div></br>'
				groupedinnerHTMLsigner[xhr.response.data[i].username] = innerHTMLsigner;
				
				newinnerHTML = newinnerHTML + innerHTMLsigner;
				if(i+1 === xhr.response.data.length){
					groupedinnerHTML.push(newinnerHTML);
				}else if((i+1)%10 ===0){
					groupedinnerHTML.push(newinnerHTML);
					var newinnerHTML = '';
				}
			};
			if(searchFind){
				document.getElementById('searchInput').value = searchFindValue;
				jumpToAnchor();
			}else{
				if (param === undefined) { 
					setPages(1);
					setinnerHTML(1);
				} else{
					setPages(param);
					setinnerHTML(param);
				}
			}
		}else{
			window.location.href = 'loginout.php';
		};
	};
	xhr.send();
	
}
function setinnerHTML(param){
	searchFind = false;
	searchFindValue = '';
	var element = document.getElementById('responid');
	element.innerHTML  = groupedinnerHTML[param - 1];
}


function tanchuang(event){
	var parentDiv = event.target.parentNode;
	var username = parentDiv.id;
	document.getElementById('pusername').value = username;
	
	var xhr = new XMLHttpRequest(); // Create XMLHttpRequest object  
	xhr.open('GET', 'queryone.php?username='+username, true); // Replace 'submit_form.php' with your server-side script URL  
	xhr.responseType = 'json';
	// Handle response  
	xhr.onload = function() {  
		if(xhr.response.status === 'success'){
			document.getElementById('myPopup').classList.add('show');
			//var pduedateElement = document.getElementById('pduedate');  
			//pduedate.value = xhr.response.data.duedate;
			
			var selectElement = document.getElementById('pisblock');  
			for (var i = 0; i < selectElement.options.length; i++) {  
				if (selectElement.options[i].value === xhr.response.data.isblock) {  
					selectElement.options[i].selected = true;  
					break; // 找到后退出循环  
				}  
			}  
			
			var selectElement = document.getElementById('pisvip');  
			for (var i = 0; i < selectElement.options.length; i++) {  
				if (selectElement.options[i].value === xhr.response.data.isvip) {  
					selectElement.options[i].selected = true;  
					break; // 找到后退出循环  
				}  
			} 
			
		}else if(xhr.response.status === 'dierror'){
			window.location.href = 'loginout.php';
		}else{
			alert(xhr.response.message);
		}; 
	};  
  
	// Send FormData object  
	xhr.send();
	
}

document.getElementById('closePopup').addEventListener('click', function() {  
	document.getElementById('myPopup').classList.remove('show');  
});  

// 也可以添加窗口点击事件来关闭弹窗（但不在弹窗内部）  
window.addEventListener('click', function(e) {  
	var popup = document.getElementById('myPopup');  
	if (e.target === popup) {  
		popup.classList.remove('show');  
	}  
});  

// 防止弹窗内部的点击事件冒泡到window上  
document.getElementById('myPopup').addEventListener('click', function(e) {  
	e.stopPropagation();  
});

document.getElementById('popupForm').addEventListener('submit', function(e) {  
	e.preventDefault();
	var formData = new FormData(this);
	var xhr = new XMLHttpRequest();
	xhr.open('POST', 'editall.php', true);
	xhr.responseType = 'json';
	xhr.onload = function() {
		if(xhr.response.status === 'success'){
			alert(xhr.response.message);
			var popup = document.getElementById('myPopup');  
			popup.classList.remove('show');
			findFunction(currentPage);
		}else if(xhr.response.status === 'dierror'){
			window.location.href = 'loginout.php';
		}else{
			alert(xhr.response.message);
		}
	}; 
	xhr.send(formData); 
});







// 更新当前页码显示  
function updateCurrentPageDisplay(page) {  
	document.getElementById('currentPage').textContent = page;  
}  

// 禁用或启用按钮  
function toggleButtons(isFirst, isLast) {  
	document.getElementById('firstPage').disabled = isFirst;  
	document.getElementById('prevPage').disabled = isFirst;  
	document.getElementById('nextPage').disabled = isLast;  
	document.getElementById('lastPage').disabled = isLast;  
}  

// 首页点击事件  
document.getElementById('firstPage').addEventListener('click', function(e) {  
	e.preventDefault();  
	currentPage = 1;  
	setinnerHTML(currentPage);
	updateCurrentPageDisplay(currentPage);  
	toggleButtons(true, false);  
});  

// 上一页点击事件  
document.getElementById('prevPage').addEventListener('click', function(e) {  
	e.preventDefault();  
	if (currentPage > 1) {  
		currentPage--;  
		setinnerHTML(currentPage);		
		updateCurrentPageDisplay(currentPage);  
		toggleButtons(currentPage === 1, currentPage === totalPages);  
	}  
});  

// 下一页点击事件  
document.getElementById('nextPage').addEventListener('click', function(e) {  
	e.preventDefault();  
	if (currentPage < totalPages) {  
		currentPage++;   
		setinnerHTML(currentPage);
		updateCurrentPageDisplay(currentPage);  
		toggleButtons(currentPage === 1, currentPage === totalPages);  
	}  
});  

// 尾页点击事件  
document.getElementById('lastPage').addEventListener('click', function(e) {  
	e.preventDefault();  	
	currentPage = totalPages;  
	setinnerHTML(currentPage);
	updateCurrentPageDisplay(currentPage);  
	toggleButtons(false, true);
	
});  

// 初始状态   
toggleButtons(true, currentPage === totalPages);  