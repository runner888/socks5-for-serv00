<?php
$requestMethod = $_SERVER['REQUEST_METHOD'];       // 获取请求的方法
$requestUri = $_SERVER['REQUEST_URI'];             // 获取请求的 URI

$path = isset($_GET['path']) ? $_GET['path'] : ''; // 从 GET 参数中获取 path
$queryParams = [];                                 // 解析查询参数
parse_str(parse_url($requestUri, PHP_URL_QUERY), $queryParams);
unset($queryParams['path']);
$queryString = http_build_query($queryParams);     // 删除 path 参数

// 构造本地文件路径
$localPath = __DIR__ . '/' . $path; // 使用 __DIR__ 获取当前目录
if ($path) {
    if (substr($path, -4) === '.php') {
        $filePath = $localPath; // 如果是.php文件，直接使用
    } else {
        $filePath = $localPath . '.php'; // 否则加上.php后缀
    }
} else {
    $filePath = __DIR__ . '/default.php'; // 默认文件，如果没有提供path
}

// 检查文件是否存在
if (!file_exists($filePath)) {
    http_response_code(404); // 设置404响应
    echo 'File not found: ' . htmlspecialchars($path);
    exit;
}

// 处理查询参数
if ($queryString) {
    // 如果有查询参数，将它们附加到文件路径（例如通过GET请求）
    parse_str($queryString, $queryArray);
    $_GET = array_merge($_GET, $queryArray); // 将查询参数放入$_GET数组
}

// 处理 POST 请求
if ($requestMethod === 'POST') {
    $postData = file_get_contents('php://input');  // 获取 POST 数据
    // 你可以在这里处理POST请求，例如将数据写入文件
}

// 输出文件内容
include($filePath);                                 // 包含文件，以执行其中的 PHP 代码

?>