<?php
error_reporting(0);
header('Content-Type: application/json;charset=UTF-8');
include 'db_Connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$json_data = urldecode(file_get_contents('php://input'));
    $data = json_decode($json_data, true);
	if (empty($data['itemid']) || empty($data['bizOrderId'])) {
        echo json_encode(['state' => false, 'errmsg' => 'itemid 或 bizOrderId 不能为空'], JSON_UNESCAPED_UNICODE);
    }else{
		$sql = "INSERT INTO users_orders (buyType, itemid, title, skuid, skutxt, price, quantity, downTime, cartstr, prebizOrderId, payType, payPwd, delmarking, ok, bizOrderId, retMsg, nickName, sign, userName) VALUES (
			" . intval($data['buyType']) . ", 
			'" . $conn->real_escape_string($data['itemid']) . "', 
			'" . $conn->real_escape_string($data['title']) . "', 
			'" . $conn->real_escape_string($data['skuid']) . "', 
			'" . $conn->real_escape_string($data['skutxt']) . "', 
			'" . $conn->real_escape_string($data['price']) . "', 
			'" . $conn->real_escape_string($data['quantity']) . "', 
			'" . $conn->real_escape_string($data['downTime']) . "', 
			'" . $conn->real_escape_string($data['cartstr']) . "', 
			'" . $conn->real_escape_string($data['prebizOrderId']) . "', 
			" . intval($data['payType']) . ", 
			'" . $conn->real_escape_string($data['payPwd']) . "', 
			'" . $conn->real_escape_string($data['delmarking']) . "', 
			'" . $conn->real_escape_string($data['ok']) . "', 
			'" . $conn->real_escape_string($data['bizOrderId']) . "', 
			'" . $conn->real_escape_string($data['retMsg']) . "', 
			'" . $conn->real_escape_string($data['nickName']) . "', 
			'" . $conn->real_escape_string($data['sign']) . "', 
			'" . $conn->real_escape_string($data['userName']) . "'
		)";
		if ($conn->query($sql) === TRUE) {
			echo json_encode(['state' => true], JSON_UNESCAPED_UNICODE);
		} else {
			echo json_encode(['state' => false, 'errmsg' => '插入失败: ' . $conn->error], JSON_UNESCAPED_UNICODE);
		}
	}
}else{
	echo json_encode(['state' => false], JSON_UNESCAPED_UNICODE);
}
include 'db_Close.php';
?>
