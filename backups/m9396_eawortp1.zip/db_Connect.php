<?php
// 创建连接
$conn = new mysqli("mysql1.serv00.com", "m9396_eawortp1", "4g5DcjKW7eNO&f5HoG#7", "m9396_eawortp1");
// 检查连接
if ($conn->connect_error) die("connectFail: " . $conn->connect_error);
?>