<?php
error_reporting(0);
header('Content-Type:text/html;charset=UTF-8');
$username = $_POST['username'];
$password = $_POST['password'];
if(empty($username) || empty($password)) {
	$data = [
            'state' => false,
            'msg' => "账号或密码不能为空！"
        ];
	die(json_encode($data, JSON_UNESCAPED_UNICODE));
}

$isvip = $_POST['isvip'];
if(empty($isvip)){$isvip = 0;};

$regdate = date("Y-m-d H:i:s");
$duedate = $_POST['duedate'];
if(empty($duedate)){
    $regdateObj = new DateTime($regdate);
    $regdateObj->modify('+1 year');
    $duedate = $regdateObj->format("Y-m-d H:i:s");
}

include 'db_Connect.php';
$sql = "SELECT * FROM users WHERE username='$username'";
$result = $conn->query($sql);

if($result->num_rows > 0){
	$data = [
			'state' => false,
			'msg' => "注册失败，用户名存在！"
		];
}else{
	$pw = md5($password.'20220531'.$password);
	$sql = "INSERT INTO users (username, password, isvip, regdate, duedate, referrer) VALUES ('$username', '$pw', $isvip, '$regdate', '$duedate', 'yushion')";  
	
	$result = $conn->query($sql);
	if ($result === TRUE) {  
		$data = [
				'state' => true,
				'msg' => "注册成功！"
			];
	} else {  
		$data = [
				'state' => false,
				'msg' => "注册失败！"
			];
	}  
}
include 'db_Close.php';
echo json_encode($data, JSON_UNESCAPED_UNICODE);
?>