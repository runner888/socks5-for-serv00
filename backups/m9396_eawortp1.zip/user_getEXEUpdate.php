<?php
error_reporting(0);
header('Content-Type: application/json;charset=UTF-8');
//echo json_encode(['version' => '1.03','update' => '1','updateUrl' => 'http://update.ini.x10.mx/servcmd'], JSON_UNESCAPED_UNICODE);
echo json_encode(['version' => '1.03','update' => '1','updateUrl' => 'https://note.youdao.com/yws/public/note/3c1cdd20c4c02c574be8b430437f9d18?sev=j1'], JSON_UNESCAPED_UNICODE);
?>