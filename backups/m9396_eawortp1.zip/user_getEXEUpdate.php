<?php
error_reporting(0);
header('Content-Type: application/json;charset=UTF-8');
echo json_encode(['version' => '1.05','update' => '1','url' => 'https://note.youdao.com/yws/public/note/3c1cdd20c4c02c574be8b430437f9d18?sev=j1'], JSON_UNESCAPED_UNICODE);
?>