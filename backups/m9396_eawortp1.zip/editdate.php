<?php  
error_reporting(0);
header('Content-Type:application/json;charset=UTF-8');
session_start();  
// 检查用户是否已登录  
if (!isset($_SESSION['user_id'])) {  
    echo json_encode(array('status' => 'dierror','message' => "失效的缓存需重新登陆"), JSON_UNESCAPED_UNICODE);     // 未登录，重定向到登录页面   
    exit;  
}

$username = $_POST['username'];
if(empty($username)) {
	$data = [
            'status' => 'error',
            'message' => "账号不能为空"
        ];
	die(json_encode($data, JSON_UNESCAPED_UNICODE));
}

$duedate = $_POST['duedate'];
if(empty($duedate)) {
	$data = [
            'status' => 'error',
            'message' => "无变动,到期时间不能为空"
        ];
	die(json_encode($data, JSON_UNESCAPED_UNICODE));
}

include 'db_Connect.php';

$sql = "SELECT * FROM users WHERE username='$username'";
$result = $conn->query($sql);
if($result->num_rows === 1){
	// 查询语句  
	$sql = "UPDATE users SET duedate='$duedate' WHERE username='$username'";
	$result = $conn->query($sql);  

	// 检查查询结果  
	if($result){  
		$data = [
				'status' => 'success',
				'message' => "修改成功"
			];
		echo json_encode($data, JSON_UNESCAPED_UNICODE); 
	} else {  
		$data = [
				'status' => 'error',
				'message' => "修改失败"
			];
		echo json_encode($data, JSON_UNESCAPED_UNICODE);
	}
}else{
	$data = [
				'status' => 'error',
				'message' => "用户不存在"
			];
	echo json_encode($data, JSON_UNESCAPED_UNICODE);
}

// 关闭连接  
include 'db_Close.php';
?>

 