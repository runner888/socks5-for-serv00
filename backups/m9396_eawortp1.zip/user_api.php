<?php
error_reporting(0);
header('Content-Type: application/json;charset=UTF-8');
$session = array(
    array(
        "id" => "1",  
        "userid" => "11",  
        "siteid" => "12",  
        "adzoneid" => "13",  
        "tb_name" => "14",  
        "appKey" => "15",  
        "apikey" => "16"  
    ),
    array(
        "id" => "2",  
        "userid" => "21",  
        "siteid" => "22",  
        "adzoneid" => "23",  
        "tb_name" => "24",  
        "appKey" => "25",  
        "apikey" => "26"  
    )
);  

$tkserverip = array(
    '123',
    '456'
);
echo json_encode(array("session" => $session,"tkserverip"=>$tkserverip), JSON_UNESCAPED_UNICODE);
?>