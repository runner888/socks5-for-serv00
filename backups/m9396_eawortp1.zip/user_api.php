<?php
error_reporting(0);
header('Content-Type: application/json;charset=UTF-8');
$session = [
    "dataoke" => [
        "appkey" => "637dbb1f4097f",
        "key"    => "201c2de10d0f4497f6977eb036e01c17",
        "pid"    => "mm_25874299_45408958_578636497"
    ]
]; 

echo json_encode($session, JSON_UNESCAPED_UNICODE);
?>