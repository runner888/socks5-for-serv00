<?php  
error_reporting(0);
header('Content-Type:application/json;charset=UTF-8'); 
session_start();
$username = $_GET['username'];  
$password = $_GET['password']; 
if(!empty($username) && !empty($password)) {
	include 'db_Connect.php';
	$pw = md5($password.'20220531'.$password);
	$sql = "SELECT * FROM users_agent WHERE username='$username' and password='$pw'";
	$result = $conn->query($sql);
	if($result->num_rows === 1){
		$row = $result->fetch_assoc();
		include 'db_Close.php';
		// 登录成功，设置会话变量  
		
		$_SESSION['user_id'] = $username;  
		// 设置会话超时时间为1小时（3600秒）  
		$session_lifetime = 3600;  
		// 注意：这里通常不需要设置cookie，因为会话是通过服务器端管理的  
		// 但如果你确实需要设置cookie来保持会话ID，可以这样做：  
		setcookie(session_name(), session_id(), time() + $session_lifetime, '/');
		// 返回成功响应  
		echo json_encode(['status' => 'success', 'message' => '登录成功'], JSON_UNESCAPED_UNICODE);  
		exit; 
	}
	include 'db_Close.php';
}
// 用户名或密码错误  
echo json_encode(['status' => 'error', 'message' => '无效的用户名或密码'], JSON_UNESCAPED_UNICODE);  
?>